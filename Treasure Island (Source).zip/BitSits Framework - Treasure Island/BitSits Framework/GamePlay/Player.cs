﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Box2D.XNA;

namespace BitSits_Framework
{
    class Player
    {
        GameContent gameContent;
        World world;
        public Body body;

        public Vector2 direction;
        SpriteEffects spriteEffects = SpriteEffects.None;

        const float MaxHelth = 100;
        public float health = MaxHelth;

        public bool inSea = false;

        Animation idle, walk, die;
        AnimationPlayer animationPlayer = new AnimationPlayer();

        public Player(GameContent gameContent, World world, Vector2 position)
        {
            this.gameContent = gameContent;
            this.world = world;

            idle = new Animation(gameContent.playerIdle, 2, 2f, true, new Vector2(0.5f));
            walk = new Animation(gameContent.playerWalk, 2, 0.2f, true, new Vector2(0.5f));
            die = new Animation(gameContent.playerDie, 2, 0.2f, false, new Vector2(0.5f));

            animationPlayer.PlayAnimation(idle);

            BodyDef bd = new BodyDef();
            bd.position = position / gameContent.b2Scale;
            bd.type = BodyType.Dynamic;
            bd.linearDamping = 10;
            body = world.CreateBody(bd);

            CircleShape cs = new CircleShape();
            cs._radius = (float)(idle.FrameWidth - 2) / gameContent.b2Scale / 2;
            FixtureDef fd = new FixtureDef();
            fd.shape = cs;
            fd.filter.groupIndex = -1;

            body.CreateFixture(fd);
        }

        public Rectangle HealthBounds
        {
            get
            {
                int halfSize = idle.FrameWidth / 3;
                return new Rectangle((int)(body.Position.X * gameContent.b2Scale) - halfSize,
                    (int)(body.Position.Y * gameContent.b2Scale) - halfSize, halfSize * 2, halfSize * 2);
            }
        }

        private Rectangle Bounds
        {
            get
            {
                int halfSize = idle.FrameWidth / 2;
                return new Rectangle((int)(body.Position.X * gameContent.b2Scale) - halfSize,
                    (int)(body.Position.Y * gameContent.b2Scale) - halfSize, halfSize * 2, halfSize * 2);
            }
        }

        public void Update(GameTime gameTime)
        {
            health = MathHelper.Clamp(health, 0, MaxHelth);

            body.ApplyLinearImpulse(direction * 1f, body.Position);

            if (health == 0) animationPlayer.PlayAnimation(die);
            else
            {
                if (direction != Vector2.Zero) animationPlayer.PlayAnimation(walk);
                else animationPlayer.PlayAnimation(idle);
            }
        }

        public void CheckCollision(Rectangle shipBounds)
        {
            for (ContactEdge ce = body.GetContactList(); ce != null; ce = ce.Next)
            {
                if (ce.Contact.IsTouching()
                    && ((ce.Contact.GetFixtureB() != body.GetFixtureList() && (string)ce.Contact.GetFixtureB().GetUserData() == "string")
                    || (ce.Contact.GetFixtureA() != body.GetFixtureList() && (string)ce.Contact.GetFixtureA().GetUserData() == "string")))
                {
                    if (!inSea)
                    {
                        if (shipBounds.Intersects(Bounds))
                        {
                            Point p = shipBounds.Center;
                            Vector2 v = new Vector2(p.X, p.Y);

                            body.Position = Tile.TileCenter(v) / gameContent.b2Scale;
                            inSea = true;
                            body.SetLinearDamping(20);

                            gameContent.soundBank.GetCue("jump").Play();
                        }
                    }
                    else
                    {
                        inSea = false; body.SetLinearDamping(10);

                        //gameContent.jump.Play();

                        Manifold m; ce.Contact.GetManifold(out m);
                        Vector2 v = m._localPoint * gameContent.b2Scale;
                        Vector2 b = body.Position * gameContent.b2Scale;
                        float theta = (float)Math.Atan2(v.Y - b.Y, v.X - b.X);

                        body.Position = Tile.TileCenter(new Vector2((float)Math.Cos(theta),
                            (float)Math.Sin(theta)) * Tile.Width + b) / gameContent.b2Scale;
                    }
                }

                //if (ce.Other.GetUserData() is Enemy) health = Math.Max(0, health - .1f);
            }
        }

        public void Draw(GameTime gameTime, SpriteBatch spriteBatch)
        {
            if (direction.X == -1) spriteEffects = SpriteEffects.FlipHorizontally;
            if (direction.X == 1) spriteEffects = SpriteEffects.None;

            animationPlayer.Draw(gameTime, spriteBatch, body.Position * gameContent.b2Scale, 
                spriteEffects, Color.White);
        }

        public void DrawHealthBar(SpriteBatch spriteBatch)
        {
            Vector2 size = new Vector2(8 * 30, 8 * 4);
            Vector2 v = new Vector2(400, 32) - size / 2;

            spriteBatch.Draw(gameContent.healthBar, v, Color.White);
            spriteBatch.Draw(gameContent.healthBar, v, new Rectangle(0, 0, (int)(health / MaxHelth * size.X),
                (int)size.Y), Color.Crimson);
        }
    }
}
